from core.retriever import Retriever


class MachRetriever(Retriever):
    pass
